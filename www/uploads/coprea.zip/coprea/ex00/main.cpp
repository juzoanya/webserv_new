/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: Constantin <coprea@student.42wolfsburg.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/26 01:08:47 by Constantin        #+#    #+#             */
/*   Updated: 2023/11/03 01:42:08 by Constantin       ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ScalarConverter.hpp"
#include <iostream>

int main(int argc, char **argv) {
    if (argc != 2) {
        return (std::cerr << "Enter only one argument" << std::endl, 1);
    }

    std::string input(argv[1]);
    ScalarConverter::convert(input);

    return 0;
}
