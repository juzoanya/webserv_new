/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScalarConverter.cpp                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: Constantin <coprea@student.42wolfsburg.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/26 01:09:20 by Constantin        #+#    #+#             */
/*   Updated: 2023/11/03 21:12:49 by Constantin       ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ScalarConverter.hpp"
#include <iostream>
#include <cmath>
#include <string>
#include <limits>
#include <climits>

ScalarConverter::ScalarConverter()
{}

ScalarConverter::ScalarConverter(const ScalarConverter &other)
{
	*this = other;
}

ScalarConverter::~ScalarConverter()
{}

ScalarConverter &ScalarConverter::operator=(const ScalarConverter &other)
{
	(void)other;
	return (*this);
}

void ScalarConverter::convert(const std::string &str) {
    int type = detectType(str);
    long tmp = std::atol(str.c_str());

    if (tmp > std::numeric_limits<int>::max() || tmp < std::numeric_limits<int>::min()) {
        type = DOUBLE;
    }

    switch (type) {
        case INT:
            intConversion(std::atoi(str.c_str()));
            break;
        case FLOAT:
            floatConversion(std::atof(str.c_str()));
            break;
        case DOUBLE:
            doubleConversion(std::atof(str.c_str()));
            break;
        case CHAR:
            charConversion(str.at(0));
            break;
        case PSEUDO:
            pseudoLiterals(str);
            break;
        case INVALID:
            std::cerr << "Error: Invalid string input" << std::endl;
            return;
    }
}

int ScalarConverter::detectType(const std::string &s) {
    if (s.length() == 1 && !isdigit(s.at(0))) {
        return CHAR;
    }

    if (s == "+inff" || s == "-inff" || s == "nanf" || s == "nan" || s == "+inf" || s == "-inf") {
        return PSEUDO;
    }

    for (size_t i = 0; i < s.length(); i++) {
        if (!isdigit(s.at(i)) && s.at(i) != '.' && s.at(i) != 'f' && s.at(i) != '-' && s.at(i) != '+') {
            return INVALID;
        } else if (i != 0 && (s[i] == '+' || s[i] == '-')) {
            return INVALID;
        }
    }

    if (s.find('.') != std::string::npos) {
        if (s.find_first_of('.') != s.find_last_of('.') || s.find_first_of('f') != s.find_last_of('f')) {
            return INVALID;
        }
        if (s.find('f') == s.length() - 1) {
            return FLOAT;
        }
        if (s.find('f') != std::string::npos) {
            return INVALID;
        }
        return DOUBLE;
    }
    if (s.find('f') != std::string::npos) {
        return INVALID;
    }

    return INT;
}

void ScalarConverter::displayResults(char charVal, bool validChar, int intVal, float floatVal, double doubleVal) {
    if (validChar && isprint(charVal)) {
        std::cout << "char: '" << charVal << "'\n";
        std::cout << "int: " << intVal << "\n";
        std::cout << "float: " << floatVal;
        if (std::fmod(floatVal, 1.0) == 0.0) {
            std::cout << ".0f\n";
        } else {
            std::cout << "f\n";
        }
        std::cout << "double: " << doubleVal;
        if (std::fmod(doubleVal, 1.0) == 0.0) {
            std::cout << ".0\n";
        } else {
            std::cout << "\n";
        }
    } else if (validChar) {
        std::cout << "char: Non displayable\n";
        std::cout << "int: " << intVal << "\n";
        std::cout << "float: " << floatVal;
        if (std::fmod(floatVal, 1.0) == 0.0) {
            std::cout << ".0f\n";
        } else {
            std::cout << "f\n";
        }
        std::cout << "double: " << doubleVal;
        if (std::fmod(doubleVal, 1.0) == 0.0) {
            std::cout << ".0\n";
        } else {
            std::cout << "\n";
        }
    } else {
        std::cout << "char: impossible\n";
        std::cout << "int: impossible\n";
        std::cout << "float: " << floatVal;
        if (std::fmod(floatVal, 1.0) == 0.0) {
            std::cout << ".0f\n";
        } else {
            std::cout << "f\n";
        }
        std::cout << "double: " << doubleVal;
        if (std::fmod(doubleVal, 1.0) == 0.0) {
            std::cout << ".0\n";
        } else {
            std::cout << "\n";
        }
    }
}

void ScalarConverter::intConversion(int intValue) {
    float floatVal = static_cast<float>(intValue);
    double doubleVal = static_cast<double>(intValue);
    char charVal = static_cast<char>(intValue);
    displayResults(charVal, true, intValue, floatVal, doubleVal);
}

void ScalarConverter::floatConversion(float floatVal) {
    double doubleVal = static_cast<double>(floatVal);
    char charVal = static_cast<char>(floatVal);
    if (floatVal > INT_MAX || floatVal < INT_MIN) {
        int intValue = INT_MIN;
        displayResults(charVal, false, intValue, floatVal, doubleVal);
        return;
    }
    int intValue = static_cast<int>(floatVal);
    displayResults(charVal, true, intValue, floatVal, doubleVal);
}

void ScalarConverter::doubleConversion(double doubleVal) {
    float floatVal = static_cast<float>(doubleVal);
    char charVal = static_cast<char>(doubleVal);
    if (doubleVal > INT_MAX || doubleVal < INT_MIN) {
        int intValue = INT_MIN;
        displayResults(charVal, false, intValue, floatVal, doubleVal);
        return;
    }
    int intVal = static_cast<int>(doubleVal);
    displayResults(charVal, true, intVal, floatVal, doubleVal);
}

void ScalarConverter::charConversion(char charVal) {
    float floatVal = static_cast<float>(charVal);
    double doubleVal = static_cast<double>(charVal);
    int intVal = static_cast<int>(charVal);
    displayResults(charVal, true, intVal, floatVal, doubleVal);
}

void ScalarConverter::pseudoLiterals(const std::string &str) {
    bool isPositive = (str[0] == '+');

    if (str == "nanf" || str == "nan") {
        float floatVal = std::numeric_limits<float>::quiet_NaN();
        double doubleVal = std::numeric_limits<double>::quiet_NaN();
        int intVal = INT_MIN;
        char charVal = static_cast<char>(floatVal);
        displayResults(charVal, false, intVal, floatVal, doubleVal);
    } else if (str == "+inff" || str == "+inf" || str == "-inff" || str == "-inf") {
        float floatVal = isPositive ? std::numeric_limits<float>::infinity() : -std::numeric_limits<float>::infinity();
        double doubleVal = isPositive ? std::numeric_limits<double>::infinity() : -std::numeric_limits<double>::infinity();
        int intVal = INT_MIN;
        char charVal = static_cast<char>(floatVal);
        displayResults(charVal, false, intVal, floatVal, doubleVal);
    } else {
        std::cerr << "Error: Invalid string input" << std::endl;
    }
}
