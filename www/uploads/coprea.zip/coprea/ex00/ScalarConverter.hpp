/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScalarConverter.hpp                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: Constantin <coprea@student.42wolfsburg.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/26 01:09:42 by Constantin        #+#    #+#             */
/*   Updated: 2023/11/03 21:05:00 by Constantin       ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SCALARCONVERTER_HPP
#define SCALARCONVERTER_HPP

#include <iostream>
#include <string>
#include <stdlib.h>

# define INT 0
# define FLOAT 1
# define DOUBLE 2
# define CHAR 3
# define PSEUDO 4
# define INVALID 5

class ScalarConverter {
public:
    static void convert(const std::string &str);

private:
    ScalarConverter();
	ScalarConverter(const ScalarConverter &other);
	~ScalarConverter();
	ScalarConverter &operator=(const ScalarConverter &other);

    static int detectType(const std::string &s);
    static void displayResults(char charVal, bool validChar, int intVal, float floatVal, double doubleVal);
    static void intConversion(int intValue);
    static void floatConversion(float floatVal);
    static void doubleConversion(double doubleVal);
    static void charConversion(char charVal);
    static void pseudoLiterals(const std::string &str);
};

#endif
