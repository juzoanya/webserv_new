/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Serializer.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: Constantin <coprea@student.42wolfsburg.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/26 22:36:16 by Constantin        #+#    #+#             */
/*   Updated: 2023/11/03 00:35:34 by Constantin       ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "Serializer.hpp"

Serializer::Serializer() {}

Serializer::Serializer(const Serializer& src) 
{
    *this = src;
}

Serializer::~Serializer() {}

Serializer& Serializer::operator=(const Serializer& rhs) 
{
    (void)rhs; // silencing unused parameter
    return *this;
}

uintptr_t   Serializer::serialize(Data* ptr) 
{
    uintptr_t serializedValue = reinterpret_cast<uintptr_t>(ptr);
    return (serializedValue);
}

Data*       Serializer::deserialize(uintptr_t raw) 
{
	Data* deserializedData = reinterpret_cast<Data*>(raw);
    return (deserializedData);
}
