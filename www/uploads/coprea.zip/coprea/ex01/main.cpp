/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: Constantin <coprea@student.42wolfsburg.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/26 22:35:20 by Constantin        #+#    #+#             */
/*   Updated: 2023/11/03 00:37:00 by Constantin       ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Serializer.hpp"

int main(void) 
{
    Data data;
    uintptr_t serialized;
    Data* deserialized;

    data.string = "Welcome to Earth, my friends! We hope you come in Peace! :)";
    data.intValue = 42424242;

    std::cout << "Before serialization:\n";
    std::cout << "ptr:\t\t" << &data << "\n";
    std::cout << "string:\t\t" << data.string << "\n";
    std::cout << "intValue:\t" << data.intValue << "\n";

    serialized = Serializer::serialize(&data);
    std::cout << "\nSerialized:\t" << serialized << "\n";

    deserialized = Serializer::deserialize(serialized);

    std::cout << "\nDeserialized:\n";
    std::cout << "ptr:\t\t" << deserialized << "\n";
    std::cout << "string:\t\t" << deserialized->string << "\n";
    std::cout << "intValue:\t" << deserialized->intValue << "\n";

    if (deserialized == &data) {
        std::cout << "--> Serialization and deserialization successfully preserved the original data." << std::endl;
    } else {
        std::cout << "--> Serialization and deserialization did not preserve the original data." << std::endl;
    }
    return 0;
}
