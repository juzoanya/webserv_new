/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Serializer.hpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: Constantin <coprea@student.42wolfsburg.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/26 22:36:41 by Constantin        #+#    #+#             */
/*   Updated: 2023/11/03 15:31:29 by Constantin       ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SERIALIZER_HPP
#define SERIALIZER_HPP

#include <iostream>
#include <stdint.h>

struct Data 
{
    int         intValue;
    std::string string;
};

// std::ostream& operator<<(std::ostream& os, const Data& data);

class Serializer {
    private:
        Serializer();
        Serializer(const Serializer &ref);
        ~Serializer();
        Serializer& operator=(const Serializer &rhs);
    public:
        static uintptr_t serialize(Data* ptr);
        static Data* deserialize(uintptr_t raw);
};

#endif