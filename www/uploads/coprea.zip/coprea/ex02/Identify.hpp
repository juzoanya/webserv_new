/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Identify.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: Constantin <coprea@student.42wolfsburg.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/26 21:32:14 by Constantin        #+#    #+#             */
/*   Updated: 2023/11/03 21:15:12 by Constantin       ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef IDENTIFY_HPP
# define IDENTIFY_HPP

#include <iostream>
#include <cstdlib>
#include <ctime>

class Base {
	public: // public virtual destructor required for polymorphism
		virtual ~Base(void);
};

// Defininig three empty classes that inherit from  Base class
class A : public Base {};
class B : public Base {};
class C : public Base {};

// generate a random instance of A, B, or C as a Base pointer
Base * generate(void);

// identify the type of an object using a pointer
void identify(Base* p);

// identify the type of an object using a reference
void identify(Base& p);

#endif
