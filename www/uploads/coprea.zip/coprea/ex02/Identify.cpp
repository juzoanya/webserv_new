/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Identify.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: Constantin <coprea@student.42wolfsburg.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/26 21:32:24 by Constantin        #+#    #+#             */
/*   Updated: 2023/11/03 16:11:26 by Constantin       ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Identify.hpp"

Base::~Base() {
    std::cout << "Base destructor called" << std::endl;
}

Base * generate(void)
{
	int	randomValue = std::rand() % 3;
	std::cout << "Random values: " << randomValue << std::endl;
	switch (randomValue)
	{
		case (0):
		{
			std::cout << "Created A instance" << std::endl;
			return (new A);
		}
		case (1):
		{
			std::cout << "Created B instance" << std::endl;
			return (new B);
		}
		case (2):
		{
			std::cout << "Created C instance" << std::endl;
			return (new C);
		}
		default:
			break;
	}
	return (NULL);
}

void identify(Base* p) {
    if (dynamic_cast<A*>(p) != NULL) 
	{
        std::cout << "type <A*> base *ptr" << std::endl;
    } 
	else if (dynamic_cast<B*>(p) != NULL) 
	{
        std::cout << "type <B*> base *ptr" << std::endl;
    } 
	else if (dynamic_cast<C*>(p) != NULL) 
	{
        std::cout << "type <C*> base *ptr" << std::endl;
    } 
	else 
	{
        std::cout << "unknown *ptr type" << std::endl;
    }
}

void identify(Base& p)
{
	try {
		(void)dynamic_cast<A&>(p);
		std::cout << "type <A&> base &ref" << std::endl;
	} catch(std::exception &e) {
		try { 
			(void)dynamic_cast<B&>(p);
			std::cout << "type <B&> base &ref" << std::endl;
		} catch(std::exception& e) {
			try {
			(void)dynamic_cast<C&>(p);
			std::cout << "type <C&> base &ref" << std::endl;
			} catch(const std::exception& e) {
				std::cerr << e.what() << " - cannot identify ref. type" << std::endl;
			}
		}
	}
}