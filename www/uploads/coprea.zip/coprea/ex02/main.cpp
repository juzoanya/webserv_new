/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: Constantin <coprea@student.42wolfsburg.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/26 21:32:30 by Constantin        #+#    #+#             */
/*   Updated: 2023/11/02 22:21:52 by Constantin       ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Identify.hpp"

int	main( void )
{
	std::srand(std::time(NULL)); // for good randomization of std::rand() in generate() 
	for (int i = 0; i < 10; i++)
	{
		std::cout << "\n ----*** Identify real type ***---- " << std::endl;
		// Generate a random object and store it in a pointer
        Base *ptr = generate();

        // Create a reference to the generated object
        Base &ref = *ptr;

        // Identify the object's type using a pointer
        identify(ptr);

        // Identify the object's type using a reference
        identify(ref);
		
		delete ptr;
	}
	return (0);
}
