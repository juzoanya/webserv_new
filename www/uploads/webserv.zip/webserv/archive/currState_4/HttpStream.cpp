/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HttpStream.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mberline <mberline@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/04 13:53:58 by mberline          #+#    #+#             */
/*   Updated: 2024/02/04 14:00:49 by mberline         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "HttpStream.hpp"

httpstream::httpstream( void )
{
    // this->eback
}

httpstream::~httpstream( void )
{ }