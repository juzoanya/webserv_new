/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   MemBuck.hpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mberline <mberline@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/08 11:20:58 by mberline          #+#    #+#             */
/*   Updated: 2024/02/08 11:21:40 by mberline         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MEM_BUCK_HPP
#define MEM_BUCK_HPP

class MemBuck {
    public:
        MemBuck( void );
        ~MemBuck( void );
    private:
};

#endif