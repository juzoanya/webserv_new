/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   CgiHandler.hpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mberline <mberline@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/23 09:45:21 by mberline          #+#    #+#             */
/*   Updated: 2024/02/03 18:57:56 by mberline         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CGI_HANDLER_HPP
#define CGI_HANDLER_HPP

#include "headers.hpp"

// class CgiHandler {
//     public:
//         CgiHandler( HttpRequest const & request, HttpConfig const & currConfig,
//             std::string const & serverIp, std::string const & serverPort,
//             std::string const & clientIp, std::string const & clientPort );
//         ~CgiHandler( void );

        
//         int createChildProcess( std::string const & cgiBinPath, std::string const & cgiScriptPath );
//     private:
//         std::vector<std::string>    _cgiArgs;
//         std::vector<std::string>    _cgiEnv;
//         std::vector<char*>          _arguments;
//         std::vector<char*>          _enviroment;
// };

#endif